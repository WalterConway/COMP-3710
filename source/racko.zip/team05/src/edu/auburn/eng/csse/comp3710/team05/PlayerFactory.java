package edu.auburn.eng.csse.comp3710.team05;

public class PlayerFactory {
	public static final String COMPUTER = "c";
	public static final String HUMAN = "h";

	public Player makePlayer(String playerType, String nameOfPlayer){
		
		
		if(playerType.equals(COMPUTER)){
			return new Computer(nameOfPlayer);
		} else
		if(playerType.equals(HUMAN)){
			return new Human(nameOfPlayer);
		} else
		return null;
		
	
	}
}
