package edu.auburn.eng.csse.comp3710.team05;

import edu.auburn.eng.csse.comp3710.team05.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.widget.Button;

/**
 * @author Walter
 *
 */
public class GameOverDialog extends DialogFragment{
	Button nextButton;
	GameCommunicator gc;
	MenuCommunicator mc;

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		gc = (GameCommunicator)activity;
		mc = (MenuCommunicator)activity;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		setCancelable(false);
		builder.setMessage(getActivity().getString(R.string.gamewinner_string) + " " + gc.getScoreboard().getNameOfWinner() +"\n"+getActivity().getString(R.string.pickup_string));
		builder.setTitle(R.string.endofgame_string);
		builder.setPositiveButton(R.string.yes_string, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
			dismiss();
			gc.startNewGame();
			}
		});
		builder.setNegativeButton(R.string.no_string, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
			dismiss();
			Racko racko = Racko.get(getActivity().getApplicationContext());
			racko.setEndOfGame(true);
			racko.newRackoGame();
			mc.launchMainMenu();
			}
		});		
		
		Dialog dialog = builder.create();
		return dialog;
	}


}
