package edu.auburn.eng.csse.comp3710.team05;

import android.content.Context;


/**
 * @author Walter
 *
 */
public class Computer extends Player{
	Context c = Racko.getContext();

	/**
	 * @param playerName Will be the player's name
	 */
	public Computer(String playerName) {
		super(playerName);
	}

	/* (non-Javadoc)
	 * @see edu.auburn.eng.csse.comp3710.TermProject.Player#onBeginTurn()
	 */
	@Override
	public void onBeginTurn() {
		Thread computerThread = new Thread (new easyPlayingStrategyThread());
		computerThread.start();

	}	


	/**
	 * @author Walter
	 * easyPlayingStrategyThread Implements a Runnable interface.
	 */
	private class easyPlayingStrategyThread implements Runnable{
		public final static int COMPUTERSSLEEPTIME = 1500;

		@Override
		public void run() {
			Context c = getContext();
			if( c != null){
				Racko racko = Racko.get(c);
				int discard = racko.viewDiscard();
				int[] rackValues = new int[10];
				for(int i = 0 ; i < 10; i++){
					rackValues[i] = getRack().get(i).getFaceValue();
				}
				try {
					Thread.sleep(COMPUTERSSLEEPTIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if((discard >=55 && discard <=60) && !(rackValues[0] >= 55 && rackValues[0] <=60)){
					racko.discard(swapCard(getRack().get(0), racko.pickupDiscard()));
				} else
					if((discard >=49 && discard <=54) && !(rackValues[1] >= 49 && rackValues[1] <=54)){
						racko.discard(swapCard(getRack().get(1), racko.pickupDiscard()));
					} else
						if((discard >=43 && discard <=48) && !(rackValues[2] >= 43 && rackValues[2] <=48)){
							racko.discard(swapCard(getRack().get(2), racko.pickupDiscard()));
						} else
							if((discard >=37 && discard <=42) && !(rackValues[3] >= 37 && rackValues[3] <=42)){
								racko.discard(swapCard(getRack().get(3), racko.pickupDiscard()));
							} else
								if((discard >=31 && discard <=36) && !(rackValues[4] >= 31 && rackValues[4] <=36)){
									racko.discard(swapCard(getRack().get(4), racko.pickupDiscard()));
								} else
									if((discard >=25 && discard <=30) && !(rackValues[5] >= 25 && rackValues[5] <=30)){
										racko.discard(swapCard(getRack().get(5), racko.pickupDiscard()));
									} else
										if((discard >=19 && discard <=24) && !(rackValues[6] >= 19 && rackValues[6] <=24)){
											racko.discard(swapCard(getRack().get(6), racko.pickupDiscard()));
										} else
											if((discard >=13 && discard <=18) && !(rackValues[7] >= 13 && rackValues[7] <=18)){
												racko.discard(swapCard(getRack().get(7), racko.pickupDiscard()));
											} else
												if((discard >=7 && discard <=12) && !(rackValues[8] >= 7 && rackValues[8] <=12)){
													racko.discard(swapCard(getRack().get(8), racko.pickupDiscard()));
												} else
													if((discard >=1 && discard <=6) && !(rackValues[9] >= 1 && rackValues[9] <=6)){
														racko.discard(swapCard(getRack().get(9), racko.pickupDiscard()));
													} else {
														//Start of the drawing strategy
														draw(racko.drawCard());
														int drawnCard = getDrawnCard().getFaceValue();
														if((drawnCard >=55 && drawnCard <=60) && !(rackValues[0] >= 55 && rackValues[0] <=60)){
															racko.discard(swapCard(getRack().get(0), getDrawnCard()));
														} else
															if((drawnCard >=49 && drawnCard <=54) && !(rackValues[1] >= 49 && rackValues[1] <=54)){
																racko.discard(swapCard(getRack().get(1), getDrawnCard()));
															} else
																if((drawnCard >=43 && drawnCard <=48) && !(rackValues[2] >= 43 && rackValues[2] <=48)){
																	racko.discard(swapCard(getRack().get(2), getDrawnCard()));
																} else
																	if((drawnCard >=37 && drawnCard <=42) && !(rackValues[3] >= 37 && rackValues[3] <=42)){
																		racko.discard(swapCard(getRack().get(3), getDrawnCard()));
																	} else
																		if((drawnCard >=31 && drawnCard <=36) && !(rackValues[4] >= 31 && rackValues[4] <=36)){
																			racko.discard(swapCard(getRack().get(4), getDrawnCard()));
																		} else
																			if((drawnCard >=25 && drawnCard <=30) && !(rackValues[5] >= 25 && rackValues[5] <=30)){
																				racko.discard(swapCard(getRack().get(5), getDrawnCard()));
																			} else
																				if((drawnCard >=19 && drawnCard <=24) && !(rackValues[6] >= 19 && rackValues[6] <=24)){
																					racko.discard(swapCard(getRack().get(6), getDrawnCard()));
																				} else
																					if((drawnCard >=13 && drawnCard <=18) && !(rackValues[7] >= 13 && rackValues[7] <=18)){
																						racko.discard(swapCard(getRack().get(7), getDrawnCard()));
																					} else
																						if((drawnCard >=7 && drawnCard <=12) && !(rackValues[8] >= 7 && rackValues[8] <=12)){
																							racko.discard(swapCard(getRack().get(8), getDrawnCard()));
																						} else
																							if((drawnCard >=1 && drawnCard <=6) && !(rackValues[9] >= 1 && rackValues[9] <=6)){
																								racko.discard(swapCard(getRack().get(9), getDrawnCard()));
																							} else {
																								racko.discard(getDrawnCard());
																							}
													}
				// If cards are in order then RACKO can be called then Racko game system should do the rest.
				if(RackoSupport.isTheRackInOrder(getRack())){
					setRackoObtained(true);
				}

				//This will give the current score in their rack now with out a bonus.
				int score = RackoSupport.calculateScore(getRack());
				setScore(score);

				try {
					Thread.sleep(COMPUTERSSLEEPTIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				racko.onCurrentPlayerEndTurn();
			}

		}//end of run method

	}//end of private class 


}

