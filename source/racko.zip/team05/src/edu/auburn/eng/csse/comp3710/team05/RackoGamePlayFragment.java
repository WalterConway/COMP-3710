package edu.auburn.eng.csse.comp3710.team05;

import java.util.Timer;
import java.util.TimerTask;

import edu.auburn.eng.csse.comp3710.team05.R;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class RackoGamePlayFragment  extends Fragment{
	Button mDrawButton, mPickupButton, mNextButton, mRackoButton, mSwapButton, mDiscardButton;
	TextView mDiscardTxtViewTR, mDiscardTxtViewBL, mDrawTxtViewTR,mDrawTxtViewBL;
	TextView mPlayer1TxtView, mPlayer2TxtView, mPlayer3TxtView, mPlayer4TxtView;
	TextView mPlayer1PtsTxtView, mPlayer2PtsTxtView, mPlayer3PtsTxtView, mPlayer4PtsTxtView;
	TextView mSlot1CardTxtView, mSlot2CardTxtView, mSlot3CardTxtView, mSlot4CardTxtView, mSlot5CardTxtView;
	TextView mSlot6CardTxtView, mSlot7CardTxtView, mSlot8CardTxtView, mSlot9CardTxtView, mSlot10CardTxtView;
	TextView mRackPtsTextView, mRackoTxtViewButton;
	LinearLayout mSlot1LL,mSlot2LL,mSlot3LL,mSlot4LL,mSlot5LL;
	LinearLayout mSlot6LL,mSlot7LL,mSlot8LL,mSlot9LL,mSlot10LL;
	ListView mRackCardLV, mPlayerLV;
	int cardFaceValueSelected=0;
	int rackScore;
	private static boolean notificationNotSeenByPlayer = true;
	private static boolean rackoOrNextState = false;
	Typeface tf;
	Timer updateTimer;
	View v;
	RackAdapter mRackAdapter;

	PlayerAdapter mPlayerAdapter;
	ArrayAdapter<String> mArrayPlayerAdapt;
	GameCommunicator gc;
	SoundCommunicator sc;
	private static boolean playerDrawn= false;

	private static final int VIBRATION_DURATION = 50;
	private static final int UPDATETIME = 500;

	@Override
	public void onAttach(Activity activity){
		super.onAttach(activity);
		gc = (GameCommunicator)activity;
		sc = (SoundCommunicator)activity;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle onSaveInstanceState){
		return inflater.inflate(R.layout.gameplay_fragment, container, false);
	}


	public void initViewSetup(){
		mRackoTxtViewButton = (TextView)getActivity().findViewById(R.id.racko_butt_txtview);
		mDiscardTxtViewTR = (TextView)getActivity().findViewById(R.id.dc_tr_tv);
		mDiscardTxtViewBL =(TextView)getActivity().findViewById(R.id.dc_bl_tv);
		mDrawTxtViewTR = (TextView)getActivity().findViewById(R.id.to_tr_tv);
		mDrawTxtViewBL = (TextView)getActivity().findViewById(R.id.to_bl_tv);
		mPlayerLV = (ListView)getActivity().findViewById(R.id.playerlistview);		
		mRackPtsTextView = (TextView)getActivity().findViewById(R.id.rack_score_tv);
		mRackCardLV = (ListView)getActivity().findViewById(R.id.rackcardlistview);
		mDrawButton = (Button)getActivity().findViewById(R.id.draw_button);
		mPickupButton = (Button)getActivity().findViewById(R.id.pickup_button);
		mNextButton = (Button)getActivity().findViewById(R.id.next_button);
		mRackoButton = (Button)getActivity().findViewById(R.id.racko_button);
		mSwapButton = (Button)getActivity().findViewById(R.id.swap_button);
		mDiscardButton = (Button)getActivity().findViewById(R.id.discard_button);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState){
		super.onActivityCreated(savedInstanceState);
		//Setting custom type face to the Rack-o TextView button
		initViewSetup();
		tf = Typeface.createFromAsset(getActivity().getAssets(), "fonts/BUXTONSKETCH.TTF");
		mRackoTxtViewButton.setTypeface(tf);

		mPlayerAdapter = new PlayerAdapter(getActivity(),gc.getPlayers());
		mPlayerLV.setAdapter(mPlayerAdapter);
		mRackCardLV.setScrollContainer(false);
		mPlayerLV.setScrollContainer(false);
		mRackAdapter = new RackAdapter(getActivity(),gc.getHumanPlayerRack());
		mRackCardLV.setAdapter(mRackAdapter);	

		mRackCardLV.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				mRackAdapter.setSelectedPosition(position);
				Vibrator vib =(Vibrator)getActivity().getSystemService("vibrator");
				vib.vibrate(VIBRATION_DURATION);
				cardFaceValueSelected = mRackAdapter.getItem(position).getFaceValue();
			}
		});

		mDrawButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sc.playButtonClickSound();
				sc.playDrawSound();
				updateRackScore();
				disableDrawButton();
				disablePickupButton();
				disableNextButton();
				enableDiscardButton();
				enableSwapButton();
				gc.playerClicksDraw();
				setHasPlayerDrawn(true);
				displayAsTheTopCardOfDeckPile(gc.getDrawnCardFromDeck());
			}
		});


		mPickupButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sc.playButtonClickSound();
				if(getCardFaceValueSelected() != 0){
					gc.playerClicksPickUp(getCardFaceValueSelected());

					disableAllButtons();
					clearDeckView();
					setCardFaceValueSelected(0);
					mRackAdapter.setSelectedPosition(-1);

					updateRackScore();
					sc.playPickupSound();
					if(gc.canPlayerRacko()){
						enableRackoButton();
						enableNextButton();
						setRackoOrNextState(true);
					} else{
						setNotificationNotSeenByPlayer(true);
						gc.playerClicksNext();
					}

				} else{
					Toast.makeText(getActivity(), R.string.selectcardfirst_string, Toast.LENGTH_SHORT).show();
				}
			}
		});

		mNextButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				sc.playButtonClickSound();
				updateRackScore();

				disableAllButtons();
				clearDeckView();
				setCardFaceValueSelected(0);
				mRackAdapter.setSelectedPosition(-1);
				setNotificationNotSeenByPlayer(true);
				setRackoOrNextState(false);
				gc.playerClicksNext();
				
			}
		});

		mRackoButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				sc.playButtonClickSound();
				sc.playRackoSound();
				updateRackScore();
				disableAllButtons();
				clearDeckView();
				setCardFaceValueSelected(0);
				setNotificationNotSeenByPlayer(true);
				setRackoOrNextState(false);
				gc.playerClicksRacko();	
			}
		});

		mSwapButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sc.playButtonClickSound();
				if(getCardFaceValueSelected() != 0){
					sc.playSwapSound();
					gc.playerClicksSwap(getCardFaceValueSelected());
					updateRackScore();
					disableAllButtons();
					clearDeckView();
					setCardFaceValueSelected(0);
					mRackAdapter.setSelectedPosition(-1);
					setHasPlayerDrawn(false);
					if(gc.canPlayerRacko()){
						enableRackoButton();
						enableNextButton();
						setRackoOrNextState(true);
					} else{
						setNotificationNotSeenByPlayer(true);
						
						gc.playerClicksNext();
					}

				} else{
					Toast.makeText(getActivity(), R.string.selectcardfirst_string, Toast.LENGTH_SHORT).show();
				}


			}
		});

		mDiscardButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sc.playButtonClickSound();
				sc.playDiscardSound();
				gc.playerClicksDiscard();
				disableAllButtons();
				clearDeckView();
				setCardFaceValueSelected(0);
				mRackAdapter.setSelectedPosition(-1);
				setHasPlayerDrawn(false);
				if(gc.canPlayerRacko()){
					enableRackoButton();
					enableNextButton();
					setRackoOrNextState(true);
				} else{
					setNotificationNotSeenByPlayer(true);
					gc.playerClicksNext();
				}
			}
		});
		//Starts the game
		disableAllButtons();
		gc.startGame();
		//the first update to the player's rack score.
		updateRackScore();
		if(gc.checkIfTurn()){
			if(hasPlayerDrawn()){
				disableDrawButton();
				disablePickupButton();
				disableNextButton();
				enableDiscardButton();
				enableSwapButton();
				displayAsTheTopCardOfDeckPile(gc.getDrawnCardFromDeck());
			}			
			if(getRackoOrNextState()){
				disableAllButtons();
				enableRackoButton();
				enableNextButton();			
			}
			if(!hasPlayerDrawn() && !getRackoOrNextState()){
			enableStartOfTurnButtons();	
			}
		}

	}

	@Override
	public void onSaveInstanceState(Bundle onSaveInstance){

	}

	public void updateRackScore(){
		rackScore = RackoSupport.calculateScore(gc.getHumanPlayerRack());
		mRackPtsTextView.setText(String.valueOf(rackScore));
	}

	public int getCardFaceValueSelected(){
		return cardFaceValueSelected;
	}
	public void setCardFaceValueSelected(int faceValueofCard){
		cardFaceValueSelected = faceValueofCard;
	}

	public void displayAsTheTopCardOfDiscardPile(int cardNumber){
		mDiscardTxtViewTR.setText(String.valueOf(cardNumber));
		mDiscardTxtViewBL.setText(String.valueOf(cardNumber));
	}
	public void displayAsTheTopCardOfDeckPile(int cardNumber){
		mDrawTxtViewTR.setVisibility(View.VISIBLE);
		mDrawTxtViewTR.setText(String.valueOf(cardNumber));
		mDrawTxtViewBL.setVisibility(View.VISIBLE);
		mDrawTxtViewBL.setText(String.valueOf(cardNumber));
	}
	public void transferDrawnCardToDiscardPile(){
		displayAsTheTopCardOfDiscardPile(Integer.parseInt(mDrawTxtViewTR.getText().toString()));
		clearDeckView();
	}
	public void clearDeckView(){
		mDrawTxtViewTR.setVisibility(View.GONE);
		mDrawTxtViewBL.setVisibility(View.GONE);
	}
	public void disableDrawButton(){
		mDrawButton.setVisibility(View.GONE);
	}
	public void disableNextButton(){
		mNextButton.setVisibility(View.GONE);
	}
	public void disableDiscardButton(){
		mDiscardButton.setVisibility(View.GONE);
	}
	public void disableSwapButton(){
		mSwapButton.setVisibility(View.GONE);
	}
	public void disablePickupButton(){
		mPickupButton.setVisibility(View.GONE);
	}
	public void disableRackoButton(){
		mRackoButton.setVisibility(View.GONE);
	}
	public void enableDrawButton(){
		mDrawButton.setVisibility(View.VISIBLE);
	}
	public void enableNextButton(){
		mNextButton.setVisibility(View.VISIBLE);
	}
	public void enableDiscardButton(){
		mDiscardButton.setVisibility(View.VISIBLE);
	}
	public void enableSwapButton(){
		mSwapButton.setVisibility(View.VISIBLE);
	}
	public void enablePickupButton(){
		mPickupButton.setVisibility(View.VISIBLE);
	}
	public void enableRackoButton(){
		mRackoButton.setVisibility(View.VISIBLE);
	}
	private boolean hasPlayerDrawn(){
		return playerDrawn;
	}
	private void setHasPlayerDrawn(boolean drawn){
		playerDrawn = drawn;
	}

	public void disableAllButtons(){
		disableDrawButton();
		disablePickupButton();
		disableNextButton();
		disableDiscardButton();
		disableSwapButton();
		disableRackoButton();

	}
	public void enableAllButtons(){
		enableDrawButton();
		enablePickupButton();
		enableNextButton();
		enableDiscardButton();
		enableSwapButton();

	}
	public void enableStartOfTurnButtons(){

			enableDrawButton();
			enablePickupButton();
			if(gc.canPlayerRacko()){
				enableRackoButton();
			}
			disableNextButton();
			disableDiscardButton();
			disableSwapButton();
		
	}

	private void setNotificationNotSeenByPlayer(boolean boolVal){
		notificationNotSeenByPlayer = boolVal;
	}
	private boolean getNotificationNotSeenByPlayer(){
		return notificationNotSeenByPlayer;
	}
	private boolean getRackoOrNextState(){
		return rackoOrNextState;
	}
	private void setRackoOrNextState(boolean newState){
		rackoOrNextState = newState;
	}

	public void update() {
		//check if the game has ended or the round has ended
		if((gc.hasEndGameBeenReached() || gc.hasEndRoundBeenReached()) && getNotificationNotSeenByPlayer()){
			if(gc.hasEndGameBeenReached()){
				sc.playGameOverSound();			
				gc.launchGameOverDialog();
				setNotificationNotSeenByPlayer(false);
			} else{
				gc.launchRoundOverDialog();
				sc.playRoundOverSound();
				setNotificationNotSeenByPlayer(false);
				gc.startNewRound();
				setNotificationNotSeenByPlayer(true);
			}	

		} else{
			mPlayerAdapter.setCurrentPlayerPosition(gc.getCurrentPlayerIndex());
			mPlayerAdapter.notifyDataSetChanged();
			mRackAdapter.notifyDataSetChanged();
			displayAsTheTopCardOfDiscardPile(gc.getDiscard());

			//notify the user that the deck has been re-shuffled.
			if(gc.getDeckReshuffleStatus()){
				Toast toast = Toast.makeText(getActivity(), R.string.deckreshuffled_string, Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();
				sc.playShuffleSound();
				gc.resetDeckReshuffleStatus();
			}

			//check if it is your turn and a flag to check if the player has bee notified of this.
			if(gc.checkIfTurn() && getNotificationNotSeenByPlayer()){
				enableStartOfTurnButtons();
				rackScore = RackoSupport.calculateScore(gc.getHumanPlayerRack());
				mRackPtsTextView.setText(String.valueOf(rackScore));
				setNotificationNotSeenByPlayer(false);
			}
		}
	}

	private class updateTask extends TimerTask {
		Handler handler;
		RackoGamePlayFragment ref;

		public updateTask(Handler handler, RackoGamePlayFragment ref) {
			super();
			this.handler = handler;
			this.ref = ref;
		}

		@Override
		public void run() {
			handler.post(new Runnable() {				
				@Override
				public void run() {
					try{
						ref.update();
					} catch(java.lang.NullPointerException e){
						System.exit(0);
					}
				}
			});
		}	
	}

	@Override
	public void onStart() {
		super.onStart();
		updateTimer = new Timer();
		updateTimer.schedule(new updateTask(new Handler(), this), 0, UPDATETIME);
	}

	@Override
	public void onStop() {
		super.onStop();
		updateTimer.cancel();
		updateTimer.purge();
	}	
}


