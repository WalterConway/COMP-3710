package edu.auburn.eng.csse.comp3710.team05;

/**
 * @author Walter
 */
public class Card implements Comparable<Card>{
	 private int faceValue;
	 
	/**
	 * @param value will be the value of the card that is created
	 */
	public Card(int value){
		faceValue = value;	
	}
	
	/**
	 * @return returns an int that is the value of the card
	 */
	public int getFaceValue(){
		return faceValue;	
	}
		
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Card other) {
		return faceValue - other.getFaceValue();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
	    return String.valueOf(faceValue);
	}
}
