package edu.auburn.eng.csse.comp3710.team05;

import java.util.ArrayList;

import edu.auburn.eng.csse.comp3710.team05.R;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.Toast;

public class MainActivity extends FragmentActivity implements MenuCommunicator, GameCommunicator, SoundCommunicator{
	public final static String GAMEPLAY_FRAG = "GAMEPLAY_FRAG";
	public final static String NUMOFPLAYERS = "NUMOFPLAYERS";
	public final static String NAMEOFPLAYER = "NAMEOFPLAYER";
	public final static String QUIT = "Quit";
	public final static String SOUND = "Sound";
	public final static String ROUNDOVER = "RoundOver";
	public final static String GAMEOVER = "GameOver";
	public final static String SETTINGS = "Settings";
	public final static String HUMAN = "h";
	public final static String COMPUTER = "c";
	private Racko racko;
	private Sound mSound;
	int mButtonSound, mEndOfGameSound, mEndOfRoundSound, mShuffleSound, mDrawSound, mDiscardSound, mSwapSound, mPickupSound, mRackoSound;
	private SharedPreferences mSharedPreferences;
	private boolean soundPref = true;
	FragmentManager fm;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initSound();
		//For preferences to load the last stored name.		
		mSharedPreferences = getSharedPreferences(SETTINGS, Context.MODE_PRIVATE);
		racko = Racko.get(getApplicationContext());
		setContentView(R.layout.activity_main);
		fm = getSupportFragmentManager();
		Fragment mainFragment = fm.findFragmentById(R.id.fragment_container);
		if(mainFragment == null){
			mainFragment = new RackoMainMenuFragment();
			fm.beginTransaction().add(R.id.fragment_container, mainFragment).commit();
		}
	}

	//Initiates things for the sound
	private void initSound(){
		mSound = new Sound(this,5);
		mEndOfGameSound = mSound.add(this, R.raw.endofgame);
		mEndOfRoundSound = mSound.add(this, R.raw.endofround);
		mShuffleSound = mSound.add(this, R.raw.shuffle);
		mDrawSound = mSound.add(this, R.raw.flip);
		mButtonSound = mSound.add(this, R.raw.buttonclick);
		mDiscardSound = mSound.add(this, R.raw.discard);
		mSwapSound = mSound.add(this, R.raw.swap);
		mPickupSound = mSound.add(this, R.raw.pickup);
		mRackoSound = mSound.add(this, R.raw.racko);
	}
	@Override
	public void launchWaiting() {
		//this should skip the launch if a game is currently being played.
		fm = getSupportFragmentManager();
		Fragment gameWaitFrag = fm.findFragmentById(R.id.fragment_container);
		gameWaitFrag = new WaitingFragment();
		FragmentTransaction fragT = fm.beginTransaction();
		fragT.replace(R.id.fragment_container, gameWaitFrag);
		fragT.addToBackStack(null);
		fragT.commit();
	}

	@Override
	public void launchGame(int numberOfPlayers, String nameOfPlayer) {
		racko = Racko.get(getApplicationContext());
		if(getStartGame()){
			racko.setNumberOfPlayers(numberOfPlayers+1);
			racko.addPlayer(HUMAN, nameOfPlayer);
			for(int i = 0; i<numberOfPlayers; i++){
				racko.addPlayer(COMPUTER, getString(R.string.computer_name_string)+" " + i);
				racko.getPlayers().get(i+1).setContext(getApplicationContext());
			}
			racko.pickFirstPlayer();
			racko.dealCards();
			racko.turnOverCard();
			racko.setStartOfGame(false);
		}

		fm = getSupportFragmentManager();
		Bundle playerBundle = new Bundle();
		playerBundle.putInt(NUMOFPLAYERS, numberOfPlayers);
		playerBundle.putString(NAMEOFPLAYER, nameOfPlayer);
		Fragment gamePlayFrag = fm.findFragmentById(R.id.fragment_container);
		gamePlayFrag = new RackoGamePlayFragment();
		gamePlayFrag.setArguments(playerBundle);
		FragmentTransaction fragT = fm.beginTransaction();
		fragT.replace(R.id.fragment_container, gamePlayFrag, GAMEPLAY_FRAG);
		fragT.commit();
	}

	@Override
	public void finish() {
		racko.newRackoGame();
		System.exit(0);
		super.finish();
		
	}

	@Override
	public void startGame() {
		racko.onStartTurn();
	}

	@Override
	public void launchInformation() {
		fm = getSupportFragmentManager();
		Fragment infoFrag = fm.findFragmentById(R.id.fragment_container);
		infoFrag = new InformationFragment();
		FragmentTransaction fragT = fm.beginTransaction();
		fragT.replace(R.id.fragment_container, infoFrag);
		fragT.addToBackStack(null);
		fragT.commit();
	}

	@Override
	public void playerClicksDiscard() {
		Card drawnCard = racko.getHumanPlayer().getDrawnCard();
		racko.discard(drawnCard);
	}

	@Override
	public void playerClicksDraw() {
		racko.getHumanPlayer().draw(racko.drawCard());
	}

	@Override
	public void playerClicksPickUp(int cardSelected) {
		Player self = racko.getHumanPlayer();
		racko.discard(self.swapCard(self.getRack().returnCard(cardSelected), racko.pickupDiscard()));
	}

	@Override
	public void playerClicksSwap(int cardSelectedFromRack) {
		Player self = racko.getHumanPlayer();
		racko.discard(self.swapCard(self.getRack().returnCard(cardSelectedFromRack), self.getDrawnCard()));
	}

	@Override
	public void playerClicksRacko() {
		Player self = racko.getHumanPlayer();
		self.setRackoObtained(true);
		racko.getHumanPlayer().setScore(RackoSupport.calculateScore(getHumanPlayerRack()));
		racko.getHumanPlayer().setYourTurn(false);
		racko.onCurrentPlayerEndTurn();	
	}

	@Override
	public void playerClicksNext() {
		racko.getHumanPlayer().setScore(RackoSupport.calculateScore(getHumanPlayerRack()));
		racko.getHumanPlayer().setYourTurn(false);
		racko.onCurrentPlayerEndTurn();		
	}

	@Override
	public Rack getHumanPlayerRack() {
		return racko.getHumanPlayer().getRack();
	}

	@Override
	public ArrayList<Player> getPlayers() {
		return racko.getPlayers();
	}

	public int getTopCardOnDeck(){
		racko.getCurrentPlayer().draw(racko.drawCard());
		return racko.getCurrentPlayer().getDrawnCard().getFaceValue();
	}

	@Override
	public void onBackPressed() {
		playButtonClickSound();
		RackoGamePlayFragment test = (RackoGamePlayFragment) getSupportFragmentManager().findFragmentByTag(GAMEPLAY_FRAG);
		if (test != null && test.isVisible()) {
			if(checkIfTurn()){
				launchQuitDialog();
			} else{
				Toast.makeText(this, R.string.your_turn_to_quit, Toast.LENGTH_SHORT).show();
			}
		}
		else {
			super.onBackPressed();
		}
	}

	@Override
	public Player getCurrentPlayer() {
		return racko.getCurrentPlayer();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		racko = null;
	}

	@Override
	public int getCurrentPlayerIndex() {
		return racko.getCurrentPlayerIndex();
	}

	@Override
	public void launchQuitDialog() {
		fm = getSupportFragmentManager();
		QuitDialogFragment dealerDiag = new QuitDialogFragment();
		dealerDiag.show(fm, QUIT);
	}

	@Override
	public boolean getStartGame() {
		return racko.getStartOfGame();
	}

	@Override
	public boolean getStartRound() {
		return racko.getStartOfRound();
	}

	@Override
	public boolean hasEndGameBeenReached() {
		return racko.getEndOfGame();
	}

	@Override
	public boolean hasEndRoundBeenReached() {

		return racko.getEndOfRound();
	}

	@Override
	public String getHumanPlayerName() {
		return racko.getHumanPlayer().toString();
	}

	@Override
	public int getDiscard() {
		return racko.viewDiscard();
	}

	@Override
	public boolean canPlayerRacko() {
		Player self = racko.getHumanPlayer();
		boolean rackInOrder = RackoSupport.isTheRackInOrder(self.getRack());
		return rackInOrder;
	}

	@Override
	public int getDrawnCardFromDeck() {
		return racko.getHumanPlayer().getDrawnCard().getFaceValue();
	}

	@Override
	public boolean checkIfTurn() {
		return racko.getHumanPlayer().getYourTurn();
	}

	@Override
	public boolean getDeckReshuffleStatus() {
		return racko.getReshuffleStatus();
	}

	@Override
	public void resetDeckReshuffleStatus() {
		racko.setReshuffleStatus(false);
	}

	@Override
	public Scoreboard getScoreboard() {
		return racko.getScoreboard();
	}

	@Override
	public void startNewRound() {
		racko.clearDiscardPile();
		racko.freshDeck();
		racko.dealCards();
		racko.turnOverCard();
		racko.setEndOfRound(false);
		racko.onStartTurn();
	}

	@Override
	public void startNewGame() {
		racko.setEndOfGame(false);
		racko.newRackoGame();
		launchWaiting();
	}

	@Override
	public void launchGameFragment() {
		fm = getSupportFragmentManager();
		Fragment gamePlayFrag = fm.findFragmentById(R.id.fragment_container);
		gamePlayFrag = new RackoGamePlayFragment();
		FragmentTransaction fragT = fm.beginTransaction();
		fragT.replace(R.id.fragment_container, gamePlayFrag, GAMEPLAY_FRAG);
		fragT.addToBackStack(null);
		fragT.commit();
	}

	@Override
	protected void onResume() {
		super.onResume();
		if(!getStartGame()){
			launchGameFragment();
		}
	}

	@Override
	public void launchRoundOverDialog() {
		fm = getSupportFragmentManager();
		RoundOverDialog roundOverDiag = new RoundOverDialog();
		roundOverDiag.show(fm, ROUNDOVER);
	}

	@Override
	public void launchGameOverDialog() {
		fm = getSupportFragmentManager();
		GameOverDialog gameOverDiag = new GameOverDialog();
		gameOverDiag.show(fm, GAMEOVER);
	}

	@Override
	public void launchMainMenu() {
		fm = getSupportFragmentManager();
		Fragment mainMenuFrag = fm.findFragmentById(R.id.fragment_container);
		mainMenuFrag = new RackoMainMenuFragment();
		FragmentTransaction fragT = fm.beginTransaction();
		fragT.replace(R.id.fragment_container, mainMenuFrag);
		fragT.addToBackStack(null);
		fragT.commit();
	}

	public boolean isSoundPref() {
		loadPreferences();
		return soundPref;
	}

	@Override
	public void playButtonClickSound() {
		if(isSoundPref()){
			mSound.play(mButtonSound);
		}
	}

	@Override
	public void playGameOverSound() {
		if(isSoundPref()){
			mSound.play(mEndOfGameSound);
		}
	}

	@Override
	public void playRoundOverSound() {
		if(isSoundPref()){
			mSound.play(mEndOfRoundSound);
		}
	}

	@Override
	public void playShuffleSound() {
		if(isSoundPref()){
			mSound.play(mShuffleSound);
		}
	}

	@Override
	public void playDrawSound() {
		if(isSoundPref()){
			mSound.play(mDrawSound);
		}
	}

	@Override
	public void playDiscardSound() {
		if(isSoundPref()){
			mSound.play(mDiscardSound);
		}

	}

	@Override
	public void playSwapSound() {
		if(isSoundPref()){
			mSound.play(mSwapSound);
		}

	}

	@Override
	public void playPickupSound() {
		if(isSoundPref()){
			mSound.play(mPickupSound);
		}
	}
	
	@Override
	public void playRackoSound() {
		if(isSoundPref()){
			mSound.play(mRackoSound);
		}
	}

	@Override
	public void launchSettings() {
		fm = getSupportFragmentManager();
		Fragment settingsFrag = fm.findFragmentById(R.id.fragment_container);
		settingsFrag = new SettingsFragment();
		FragmentTransaction fragT = fm.beginTransaction();
		fragT.replace(R.id.fragment_container, settingsFrag);
		fragT.addToBackStack(null);
		fragT.commit();
	}

	public void loadPreferences(){
		soundPref = mSharedPreferences.getBoolean(SOUND, true);
	}






}
