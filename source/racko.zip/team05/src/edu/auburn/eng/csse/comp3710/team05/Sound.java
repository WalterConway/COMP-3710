package edu.auburn.eng.csse.comp3710.team05;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

public class Sound {
	private SoundPool     mSoundPool;    
    private AudioManager  mAudioManager; 

    public Sound( Context context, int max ) {
        mSoundPool    = new SoundPool( max, AudioManager.STREAM_MUSIC, 0 );
        mAudioManager = (AudioManager)context.getSystemService( Context.AUDIO_SERVICE );
    }
    
    public int add( Context context, int resId ) {
        int soundId= mSoundPool.load( context, resId ,1 );
        return soundId;
    }

    public int play( int soundId, int repeat, float rate ) {
        float streamVolume= mAudioManager.getStreamVolume( AudioManager.STREAM_MUSIC );
        streamVolume= streamVolume / mAudioManager.getStreamMaxVolume( AudioManager.STREAM_MUSIC );
        int streamId= mSoundPool.play( soundId, streamVolume, streamVolume, 1, repeat, rate );
        return streamId;
    }
      
    public int play( int soundId ) {
        return play( soundId, 0, 1.0f );
    }

    public void stop( int streamId ) {
        mSoundPool.stop( streamId );
    }
}
