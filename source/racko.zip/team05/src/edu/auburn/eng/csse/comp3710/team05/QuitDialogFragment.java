package edu.auburn.eng.csse.comp3710.team05;

import edu.auburn.eng.csse.comp3710.team05.R;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.DialogFragment;
import android.view.KeyEvent;
import android.widget.Button;

public class QuitDialogFragment extends DialogFragment{
	Button mDealButton;
	Button mShuffleButton;
	Vibrator vib;
	
	
	@Override
	public Dialog onCreateDialog( Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
    	setCancelable(false);
        builder.setMessage(R.string.quit_areyousure);
        builder.setTitle(R.string.quit_string);
        
        builder.setOnKeyListener(new DialogInterface.OnKeyListener() {
			
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
		            return true; // Pretend we processed it
		        }
		        return false; // Any other keys are still processed as normal
			}
		});
        builder.setPositiveButton(R.string.no_string, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
		    	dismiss();
			}
		});
        
        builder.setNegativeButton(R.string.yes_string, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
		    	getActivity().finish();
		    	
			}
		});
		
		
		return builder.create();
	}
	
	




}
