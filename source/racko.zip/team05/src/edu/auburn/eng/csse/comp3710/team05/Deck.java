package edu.auburn.eng.csse.comp3710.team05;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collections;

/**
 * @author Walter
 *
 */
public class Deck {

private ArrayList<Card> deck;

/**
 * 
 */
public Deck(){
    deck = new ArrayList<Card>();
    for(int i = 0; i < 60; i++)
    {
        deck.add(new Card(i + 1));
    }
    shuffle();
}


/**
 * @return The Card that is on top the Deck Currently.
 */
public Card popCardOffDeck(){
	return deck.remove(0);	
}

/**
 * @return The current size of the Deck as an int.
 */
@SuppressWarnings("unused")
private int getSize(){
	return deck.size();
}

/**
 * Shuffles the cards that in the deck.
 */
public void shuffle(){
	Collections.shuffle(deck);
}

/**
 * @return true if the deck is empty false otherwise.
 */
public boolean isEmpty()
{
    return deck.isEmpty();
}

/**
 * Useful when re-shuffling.
 * @param cards Will add multiple cards to the deck at one time.
 * 
 */
public void addCardsToDeck(AbstractList<Card> cards){
	deck.addAll(cards);
}

}
