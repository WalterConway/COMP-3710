package edu.auburn.eng.csse.comp3710.team05;

import edu.auburn.eng.csse.comp3710.team05.R;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class WaitingFragment extends Fragment{
	SeekBar mSeekBar;
	TextView mNumOfPlayersTxtView;
	EditText mInputName;
	Button mStartButt;
	int numberOfPlayers = 1;
	GameCommunicator gc;
	SoundCommunicator sc;
	SharedPreferences mSharedPreferences;
	String mHumanName;
	public static final String SOUND = "Sound";
	public static final String SETTINGS= "Settings";
	String NAME = "Name";
@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		gc = (GameCommunicator)activity;
		sc = (SoundCommunicator)activity;
		mSharedPreferences = getActivity().getSharedPreferences(SETTINGS, Context.MODE_PRIVATE);
	}

public void initViewSetup(){
	mInputName = (EditText)getActivity().findViewById(R.id.name_input_edittext);
	mNumOfPlayersTxtView = (TextView)getActivity().findViewById(R.id.totalnumberplayertxtview);
	mSeekBar = (SeekBar)getActivity().findViewById(R.id.numberofplayersseekbar);
	mStartButt = (Button)getActivity().findViewById(R.id.play_button_waiting);
}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		initViewSetup();
		mHumanName = mSharedPreferences.getString(NAME, "");
		mInputName.setText(mHumanName);

		
		mNumOfPlayersTxtView.setText(String.valueOf(numberOfPlayers));
		mInputName.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				savePlayerNamePreference(s.toString());
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}			
			@Override
			public void afterTextChanged(Editable s) {				
			}
		});
		
		mSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
		
		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {			
		}
		
		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {			
		}
		
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
			numberOfPlayers = progress+1;
			mNumOfPlayersTxtView.setText(String.valueOf(numberOfPlayers));
		}
	});	
	
	mStartButt.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			sc.playButtonClickSound();
			if(mInputName.getText().length() > 1){
			gc.launchGame(numberOfPlayers,mInputName.getText().toString());
			} else {
				Toast toast = Toast.makeText(getActivity(), R.string.enternametoplay_string, Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();
			}
		}
	});
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return inflater.inflate(R.layout.waiting_fragment, container, false);
	}
	
	public void savePlayerNamePreference(String name){
		 mSharedPreferences = getActivity().getSharedPreferences(SETTINGS, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = mSharedPreferences.edit();
		editor.putString(NAME, name);
		editor.commit();
	}
}
