package edu.auburn.eng.csse.comp3710.team05;

import edu.auburn.eng.csse.comp3710.team05.R;
import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class RackoMainMenuFragment extends Fragment {
	Button mPlayButton, mInformationButton, mExitButton, mSettingsButton;
	MenuCommunicator mc;
	SoundCommunicator sc;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle onSaveInstanceState){		
		return inflater.inflate(R.layout.mainmenu_fragment, container, false);
	}

	public void onAttach(Activity activity){
		super.onAttach(activity);
		mc = (MenuCommunicator)activity;
		sc = (SoundCommunicator)activity;	
	}

	public void initViewSetup(){
		mPlayButton = (Button)getActivity().findViewById(R.id.play_button);
		mInformationButton = (Button)getActivity().findViewById(R.id.info_button);
		mExitButton = (Button)getActivity().findViewById(R.id.exit_button);
		mSettingsButton = (Button)getActivity().findViewById(R.id.settings_button);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState){
		super.onActivityCreated(savedInstanceState);
		initViewSetup();		
		mPlayButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sc.playButtonClickSound();
				mc.launchWaiting();

			}
		});

		mInformationButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sc.playButtonClickSound();
				mc.launchInformation();

			}
		});

		mExitButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sc.playButtonClickSound();
				getActivity().finish();


			}
		});

		mSettingsButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sc.playButtonClickSound();
				mc.launchSettings();

			}
		});
	}
}
