package edu.auburn.eng.csse.comp3710.team05;

public interface SoundCommunicator {

	void playButtonClickSound();
	void playGameOverSound();
	void playRoundOverSound();
	void playShuffleSound();
	void playDrawSound();
	void playDiscardSound();
	void playSwapSound();
	void playPickupSound();
	void playRackoSound();
}
