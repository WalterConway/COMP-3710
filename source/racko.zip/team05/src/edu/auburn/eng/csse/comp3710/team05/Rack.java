package edu.auburn.eng.csse.comp3710.team05;

import java.util.ArrayList;
import java.util.Iterator;

public class Rack {
	private ArrayList<Card> rack;

	public Rack()
	{
		rack = new ArrayList<Card>(10);
	}

	public Card get(int index){
		return rack.get(index);
	}

	public ArrayList<Card> getRack(){
		return rack;
	}

	public Card swap(Card unwantedCard, Card replacementCard)
	{
		int cardPlacementValue = cardPlacement(unwantedCard);

		if(cardPlacementValue != -1)
		{
			return rack.set(cardPlacementValue, replacementCard);
		} else
		{
			return null;
		}
	}

	public boolean add(Card card)
	{
		return rack.add(card);
	}

	public ArrayList<Card> unRack()
	{
		ArrayList<Card> tempRack = rack;
		clearRack();
		return tempRack;
	}

	public int getSize()
	{
		return rack.size();
	}

	//pass in a card and it will tell you where it is located in the rack.
	private int cardPlacement(Card card)
	{
		return rack.indexOf(card);

	}

	public Card returnCard(int faceValue)
	{
		Iterator<Card> i = rack.iterator();
		while(i.hasNext()){
			Card tempCard = i.next();
			if(tempCard.getFaceValue() == faceValue){
				return tempCard;
			}
		}
		return null;
	}

	private void clearRack(){
		rack.clear();
	}

}
