package edu.auburn.eng.csse.comp3710.team05;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;

import android.content.Context;

public class Scoreboard {

	private Hashtable<String,Integer> ht;
	private Enumeration<String> enumeration;
	private static Scoreboard sScoreboard;
	private ArrayList<String> roundWinnerList;

	@SuppressWarnings("unused")
	private Context mAppContext;

	private Scoreboard(Context appContext)
	{
		mAppContext = appContext;
		ht = new Hashtable<String,Integer>();
		roundWinnerList = new ArrayList<String>();
	}
	
	public static Scoreboard get(Context c){
		if(sScoreboard == null){
			sScoreboard = new Scoreboard(c.getApplicationContext());
		}
		return sScoreboard;
	}

	public void updateScore(Player player, int score){
		if(ht.containsKey(player.getName()))
		{
			ht.put(player.getName(), Integer.valueOf(getPlayerScore(player) + score));
		}
	}
	
	public void addRoundWinnerToList(Player player){
		roundWinnerList.add(player.getName());
	}
	
	public String getWinnerForRoundNumber(int roundNumber){
		return roundWinnerList.get(roundNumber);
	}
	
	public String getWinnerForMostRecentRound(){
		return roundWinnerList.get(roundWinnerList.size()-1);
	}
	
	public void addToBoard(Player player)
	{
		ht.put(player.getName(), Integer.valueOf(0));
	}

	public int getPlayerScore(Player player)
	{
		Integer score = ht.get(player.getName());
		if(score == null){
			return 0;

		}else {
			return score.intValue();
		}
	}

	public int getHighestScore(){
		ArrayList<Integer> scoreList = new ArrayList<Integer>(ht.values());
		return Collections.max(scoreList).intValue();
	}

	public String getNameOfWinner()
	{
		ArrayList<String> winnerList = new ArrayList<String>();
		enumeration = ht.keys();
		do
		{
			if(!enumeration.hasMoreElements())
			{
				break;
			}
			String playerName = (String)enumeration.nextElement();
			if(((Integer)ht.get(playerName)).intValue() >= 500)
			{
				winnerList.add(playerName);
			}
		} while(true);
		if(winnerList.size() == 0)
		{
			return null;
		}
		if(winnerList.size() > 1)
		{
			int tempValue = 0;
			String highScorePlayer = "";
			for(int i = 0; i < winnerList.size(); i++)
			{
				if(((Integer)ht.get(winnerList.get(i))).intValue() > tempValue)
				{
					tempValue = ((Integer)ht.get(winnerList.get(i))).intValue();
					highScorePlayer = (String)winnerList.get(i);
				}
			}
			return highScorePlayer;
		} else
		{
			return (String)winnerList.get(0);
		}
	}
}
