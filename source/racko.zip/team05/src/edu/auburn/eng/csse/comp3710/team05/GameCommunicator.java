package edu.auburn.eng.csse.comp3710.team05;

import java.util.ArrayList;


/**
 * @author Walter
 *
 */
public interface GameCommunicator {
	/**
	 * @param numberOfPlayers The number of players that the game will be played with
	 * @param nameOfPlayer This is the name of the player of the game that is not the computer
	 */
	public void launchGame(int numberOfPlayers, String nameOfPlayer);
	
	/**
	 * This launches the intent used to goto the game fragment.
	 */
	public void launchGameFragment();
	
	/**
	 * This starts the game when the user interface of the game fragments finishes loading.
	 */
	public void startGame();
	
	/**
	 * This is invoked when the user clicks the discard button.
	 */
	public void playerClicksDiscard();
	
	/**
	 * This is invoked when the user clicks the draw button 
	 */
	public void playerClicksDraw();
	
	/**
	 * This is invoked when the user clicks pick up in the game fragment
	 * @param cardSelected is the face value of the card being selected in the game fragment
	 */
	public void playerClicksPickUp(int cardSelected);
	
	/**
	 * This is invoked when the user clicks the swap button.
	 * @param cardSelectedFromRack is the face value of the card being selected in the game fragment
	 */
	public void playerClicksSwap(int cardSelectedFromRack);
	
	/**
	 * This is invoked when the user clicks the Racko button.
	 */
	public void playerClicksRacko();
	
	/**
	 * This is invoked when the user clicks the next button.
	 */
	public void playerClicksNext();
	
	/**
	 * This invoked to check if the user can racko.
	 * @return a boolean that is true if the player can racko and false otherwise.
	 */
	public boolean canPlayerRacko();
	
	/**
	 * This is invoked to receive the current player.
	 * @return the player that is currently selected to go.
	 */
	public Player getCurrentPlayer();
	
	/**
	 * This returns the human's name that was entered.
	 * @return String that is the humans's name.
	 */
	public String getHumanPlayerName();
	
	/**
	 * @return an int that is the face value of the card from the deck.
	 */
	public int getDrawnCardFromDeck();
	
	/**
	 * @return a Rack object of the human player.
	 */
	public Rack getHumanPlayerRack();
	
	/**
	 * @return an ArrayList of Player objects
	 */
	public ArrayList<Player> getPlayers();
	
	/**
	 * @return an int of the discard card.
	 */
	public int getDiscard();
	
	/**
	 * @return true if it is the human's turn and false otherwise.
	 */
	public boolean checkIfTurn();
	
	/**
	 * @return int of the currently selected player.
	 */
	public int getCurrentPlayerIndex();
	
	/**
	 * @return true if the game just started.
	 */
	public boolean getStartGame();
	
	/**
	 * @return true if the round of the game just started.
	 */
	public boolean getStartRound();
	
	/**
	 * @return true if the game has ended.
	 */
	public boolean hasEndGameBeenReached();
	
	/**
	 * @return true if the a round of the game has been reached.
	 */
	public boolean hasEndRoundBeenReached();
	
	/**
	 * @return true if the deck has been re-shuffled false otherwise.
	 */
	public boolean getDeckReshuffleStatus();
	
	/**
	 * resets the deck re-shuffle status back to false when called.
	 */
	public void resetDeckReshuffleStatus();
	
	/**
	 * This is invoked to launch the intent to show the quit dialog.
	 */
	public void launchQuitDialog();
	
	/**
	 * This is invoked to launch the intent to show the round over dialog.
	 */
	public void launchRoundOverDialog();
	
	/**
	 * This is invoked to launch the intent to show the Game over dialog.
	 */
	public void launchGameOverDialog();
	
	/**
	 * @return retrieves the score board of the racko game.
	 */
	public Scoreboard getScoreboard();
	
	/**
	 * This is invoked to start a new round.
	 */
	public void startNewRound();
	
	/**
	 * This is invoked to start a new game.
	 */
	public void startNewGame();
	
}
