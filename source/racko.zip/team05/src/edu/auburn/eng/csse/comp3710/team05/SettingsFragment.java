package edu.auburn.eng.csse.comp3710.team05;

import edu.auburn.eng.csse.comp3710.team05.R;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

public class SettingsFragment extends Fragment{
	private ToggleButton mSoundToggle;
	private SharedPreferences mSharedPreferences;
	private boolean soundPref;
	public static final String SOUND = "Sound";
	public static final String SETTINGS= "Settings";

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle onSaveInstanceState){
		return inflater.inflate(R.layout.settings_fragment, container, false);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		mSoundToggle = (ToggleButton)getActivity().findViewById(R.id.sound_toggle);		 
		mSharedPreferences = getActivity().getSharedPreferences(SETTINGS, Context.MODE_PRIVATE);
		soundPref = mSharedPreferences.getBoolean(SOUND, true);
		mSoundToggle.setChecked(soundPref);
		mSoundToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				saveSoundPreference(isChecked);				
			}
		});

		super.onActivityCreated(savedInstanceState);
	}

	public void saveSoundPreference(boolean isChecked){
		mSharedPreferences = getActivity().getSharedPreferences(SETTINGS, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = mSharedPreferences.edit();
		editor.putBoolean(SOUND, isChecked);
		editor.commit();
	}	
}
