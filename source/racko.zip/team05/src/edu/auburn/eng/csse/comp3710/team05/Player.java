package edu.auburn.eng.csse.comp3710.team05;

import java.util.ArrayList;

import android.content.Context;


public class Player {
	private String name;
	private int score;
	private Rack rack;
	private Card drawnCard;

	private Context context;
	boolean rackoObtained;

	public Player(String playerName)
	{
		context = null;
		score = 0;
		drawnCard = null;
		rackoObtained = false;
		name = playerName;
		rack = new Rack();
	}

	public Context getContext(){
		return context;
	}
	public void setContext(Context c){
		context = c; 
	}

	public Rack getRack()
	{
		return rack;
	}
	public ArrayList<Card> getRackArrayList(){
		return rack.getRack();
	}

	public void onBeginTurn(){

	}

	public boolean addToRack(Card card)
	{
		return rack.add(card);
	}

	public String getName()
	{
		return name;
	}

	public Card swapCard(Card oldCard, Card newCard)
	{
		return getRack().swap(oldCard, newCard);
	}

	public Card getDrawnCard()
	{
		return drawnCard;
	}

	public void draw(Card card)
	{
		drawnCard = card;
	}

	public int getScore()
	{
		return score;
	}

	public void setScore(int newval){
		score = newval;
	}

	public boolean getRackoObtained()
	{
		return rackoObtained;
	}

	public void setRackoObtained(boolean wasRackoObtained)
	{
		rackoObtained = wasRackoObtained;
	}

}
