package edu.auburn.eng.csse.comp3710.team05;

public interface MenuCommunicator {

	public void launchInformation();
	public void launchWaiting();
	public void launchMainMenu();
	public void launchSettings();
	
}
