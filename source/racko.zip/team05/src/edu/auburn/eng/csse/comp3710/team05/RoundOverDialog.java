package edu.auburn.eng.csse.comp3710.team05;

import edu.auburn.eng.csse.comp3710.team05.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.widget.Button;

public class RoundOverDialog extends DialogFragment{
	Button nextButton;
	GameCommunicator gc;

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		gc = (GameCommunicator)activity;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		setCancelable(false);
		builder.setMessage(getActivity().getString(R.string.roundwinner_string) + " " + gc.getScoreboard().getWinnerForMostRecentRound());
		builder.setTitle(R.string.endofround_string);
		builder.setNeutralButton(R.string.okay_string, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
			dismiss();
			}
		});
		Dialog dialog = builder.create();
		return dialog;
	}


}
