package edu.auburn.eng.csse.comp3710.team05;

public class RackoSupport {

	public static int calculateBonusPts(int sequenceAmount)
	{
		switch(sequenceAmount)
		{
		case 0:
		case 1:
		case 2:
			return 0;

		case 3:
			return 50;

		case 4:
			return 100;

		case 5:
			return 200;

		case 6:
		default:
			return 400;
		}
	}

	public static int calculateScore(int ascendingOrderLimit, int numbersInSequenceAmount, boolean didPlayerGoOut)
	{
		if(ascendingOrderLimit <=10){
			if(didPlayerGoOut) {
				return ascendingOrderLimit * 5 + 25 + calculateBonusPts(numbersInSequenceAmount);
			} else {
				return ascendingOrderLimit * 5;
			}
		} else {
			return 0;
		}
	}
	//Calculate rack with no bonus added
	public static int calculateScore(Rack rack)
	{    	
		int count = 1;
		for(int i=rack.getSize()-1; i> 0; i --){
			if((rack.get(i).compareTo(rack.get(i-1))) <=0){
				count++;
			} else {
				break;
			}
		}
		return count * 5;
	}

	//checks if the cards are in order
	public static boolean isTheRackInOrder(Rack rack)
	{
		for(int i = 10; i > 1; i--)
		{
			if(rack.get(i - 1).compareTo(rack.get(i - 2)) >= 0)
			{
				return false;
			}
		}
		return true;
	}

	public static int orderLimit(Rack rack)
	{
		if(rack.getSize() == 0)
		{
			return 0;
		}
		int count = 1;
		for(int i = rack.getSize(); i > 1; i--)
		{
			if(rack.get(i - 1).compareTo(rack.get(i - 2)) < 0)
			{
				count++;
			} else
			{
				return count;
			}
		}
		return count;
	}
//Returns the highest sequence amount in the rack
	public static int sequenceAmount(Rack rack)
	{
		int highestSequenceAmount = 0;
		int count = 1;
		for(int i = 9; i> 0; i--){
			if((rack.get(i).compareTo(rack.get(i-1))) ==-1){
				count++;
			} else {
				if(count > highestSequenceAmount){
					highestSequenceAmount = count;
				}
				count = 1;
			}
		}
		if(count > highestSequenceAmount){
			highestSequenceAmount = count;
		}
		return highestSequenceAmount;
	}
}
