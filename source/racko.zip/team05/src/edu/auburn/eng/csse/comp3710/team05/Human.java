package edu.auburn.eng.csse.comp3710.team05;

public class Human extends Player{
private boolean yourTurn = false;

	/**
	 * @param playerName will be the name of the human player
	 */
	public Human(String playerName) {
		super(playerName);
	}
	
	/**
	 * @return true if it is the human's turn and false otherwise
	 */
	public boolean getYourTurn(){
		return yourTurn;
	}
	/**
	 * @param turn set true if it is the human's turn false otherwise.
	 */
	public void setYourTurn(boolean turn){
		yourTurn = turn;
	}
	/* (non-Javadoc)
	 * @see edu.auburn.eng.csse.comp3710.TermProject.Player#onBeginTurn()
	 */
	public void onBeginTurn(){
	setYourTurn(true);
	}

}
