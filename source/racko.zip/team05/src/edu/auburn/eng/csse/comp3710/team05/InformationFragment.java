package edu.auburn.eng.csse.comp3710.team05;

import edu.auburn.eng.csse.comp3710.team05.R;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

public class InformationFragment extends Fragment{
	WebView wv;
	private final static String HELPSITE = "file:///android_asset/html/index.html";
	

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle onSaveInstanceState){
		return inflater.inflate(R.layout.info_fragment, container, false);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		wv = (WebView)getActivity().findViewById(R.id.instructions_webview);
		wv.loadUrl(HELPSITE);
		super.onActivityCreated(savedInstanceState);
	}
}
