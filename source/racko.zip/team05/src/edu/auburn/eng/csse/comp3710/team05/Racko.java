package edu.auburn.eng.csse.comp3710.team05;

import java.util.ArrayList;
import java.util.Random;
import java.util.Stack;

import android.content.Context;
public class Racko
{
	private static Racko sRacko;
	private static Context mAppContext;
	private static int currentPlayer;
	private static int currentDealer;
	private static int humanPlayer;
	private static boolean reshuffleStatus;
	private static boolean endOfGame;
	private static boolean endOfRound;
	private static boolean startOfRound;
	private static boolean startOfGame;
	private static ArrayList<Player> players;
	private static Deck deck;
	private static Stack<Card> discardPile;
	private static Scoreboard scoreboard;
	private static PlayerFactory plyrFactory;
	private static final int MAXHIGHSCORE = 500;

	private Racko(Context appContext)
	{

		endOfGame = false;
		endOfRound = false;
		startOfRound = true;
		startOfGame = true;
		reshuffleStatus = false;
		mAppContext = appContext;
		currentPlayer = 0;
		currentDealer = 0;
		humanPlayer = 0;
		plyrFactory = new PlayerFactory();
		deck = new Deck();
		discardPile = new Stack<Card>();
		scoreboard = Scoreboard.get(appContext);
	}


	public boolean getEndOfGame(){
		return endOfGame;
	}

	public boolean getReshuffleStatus(){
		return reshuffleStatus;
	}
	public void setReshuffleStatus(boolean status){
		reshuffleStatus = status;
	}
	public void setEndOfGame(boolean boolVal){
		endOfGame = boolVal;
	}

	public boolean getEndOfRound(){
		return endOfRound;
	}

	public void freshDeck(){
		deck = new Deck();
	}
	public void clearDiscardPile(){
		getDiscardPile().clear();
	}
	public void setEndOfRound(boolean boolVal){
		endOfRound = boolVal;
	}
	public boolean getStartOfGame(){
		return startOfGame;
	}

	public void setStartOfGame(boolean boolVal){
		startOfGame = boolVal;
	}

	public boolean getStartOfRound(){
		return startOfRound;
	}

	public void setStartOfRound(boolean boolVal){
		startOfRound = boolVal;
	}

	public static Racko get(Context c){
		if(sRacko == null){
			sRacko = new Racko(c.getApplicationContext());
		}
		return sRacko;
	}

	public void newRackoGame(){
		sRacko = null;
	}

	public Human getHumanPlayer() {
		return (Human)getPlayerAtIndex(humanPlayer);
	}
	//Must be called before starting the game.
	public void setNumberOfPlayers(int numberOfPlayers){
		players = new ArrayList<Player>(numberOfPlayers);
	}

	public ArrayList<Player> getPlayers(){
		return players;
	}

	public Deck getDeck(){
		return deck;
	}

	public Scoreboard getScoreboard(){
		return scoreboard;
	}

	//type is 'c' for computer type or 'h' for human type
	public void addPlayer(String typeOfPlayer, String name) {
		getPlayers().add(getPlayerFactory().makePlayer(typeOfPlayer, name));//plyrFactory will return null.
		getScoreboard().addToBoard((Player)getPlayers().get(getPlayers().size() - 1));        
	}

	public PlayerFactory getPlayerFactory(){
		return plyrFactory;
	}

	private Stack<Card> getDiscardPile(){
		return discardPile;
	}

	private void setCurrentPlayerIndex(int playerNumber)
	{
		currentPlayer = playerNumber;
	}

	public int getCurrentPlayerIndex()
	{
		return currentPlayer;
	}

	public static Context getContext(){
		return mAppContext;
	}

	public Player getCurrentPlayer()
	{
		return (Player)getPlayers().get(getCurrentPlayerIndex());
	}

	public Player getCurrentDealer()
	{
		return (Player)getPlayers().get(getCurrentDealerIndex());
	}

	private void setCurrentDealerIndex(int playerNumber)
	{
		currentDealer = playerNumber;
	}

	private Player getPlayerAtIndex(int index){
		return getPlayers().get(index);
	}

	private int getCurrentDealerIndex()
	{
		return currentDealer;
	}

	public int viewDiscard()
	{
		if(getDiscardPile().peek() == null){
			return 0;    		
		} else {
			return ((Card)getDiscardPile().peek()).getFaceValue();
		}
	}

	public int nextPlayer(int presentPlayer)
	{
		if(presentPlayer < getPlayers().size() - 1)
		{
			return presentPlayer + 1;
		} else
		{
			return presentPlayer - (getPlayers().size() - 1);
		}
	}

	public void onCurrentPlayerEndTurn() {

		if(getCurrentPlayer().getRackoObtained()) {
			Player plyr;
			Rack rck;
			int score;
			int orderLimit;
			int sequenceAmount;
			//score stuff
			for(int i = 0; i < getPlayers().size(); i++){
				plyr = getPlayers().get(i);
				rck = plyr.getRack();
				//calculate scores on rack for the player that went out
				if(plyr.getRackoObtained()){
					orderLimit = RackoSupport.orderLimit(rck);
					sequenceAmount = RackoSupport.sequenceAmount(rck);
					score = RackoSupport.calculateScore(orderLimit, sequenceAmount, true);
					getScoreboard().updateScore(plyr, score);
					getScoreboard().addRoundWinnerToList(plyr);
				}else{
					//calculate scores for the others
					//update those scores to the score board
					score = RackoSupport.calculateScore(rck);
					getScoreboard().updateScore(plyr, score);
				}
				rck.unRack();
			}

			//find out if end of game score has been reached
			//if score has been reached then set end of game flag
			//if score has not been reached then set the end of round flag
			if(isGameOver()){
				setEndOfGame(true);
			} else {
				setEndOfRound(true);
			}
			//resetting rack-o flag
			getCurrentPlayer().setRackoObtained(false);
			//moving to the next player
			setCurrentPlayerIndex(nextPlayer(getCurrentDealerIndex()));
			setCurrentDealerIndex(nextPlayer(getCurrentDealerIndex()));
		}else{
			setCurrentPlayerIndex(nextPlayer(getCurrentPlayerIndex()));
			onStartTurn();
		}
	}

	public void onStartTurn(){
		getCurrentPlayer().onBeginTurn();
	}

	public void dealCards()
	{
		for(int i = 0; i < 10; i++)
		{
			for(int j = 0; j < getPlayers().size(); j++)
			{
				((Player)getPlayers().get(nextPlayer(getCurrentDealerIndex() + j))).addToRack(getDeck().popCardOffDeck());
			}
		}
	}

	public void pickFirstPlayer()
	{
		Random generator = new Random();
		int randomNumber = generator.nextInt(getPlayers().size());
		setCurrentDealerIndex(randomNumber);
		setCurrentPlayerIndex(nextPlayer(randomNumber));
	}

	public void turnOverCard()
	{
		getDiscardPile().push(getDeck().popCardOffDeck());
	}

	public Card drawCard()
	{
		if(getDeck().isEmpty())
		{
			setReshuffleStatus(true);
			endOfDeckReshuffle();
		}
		return (Card)getDeck().popCardOffDeck();
	}

	public void addCardsToDeck(ArrayList<Card> cardList){

	}

	public void shuffleDeck(){
		getDeck().shuffle();
	}

	public Card pickupDiscard()
	{
		return (Card)getDiscardPile().pop();
	}

	public void discard(Card discardedCard)
	{
		getDiscardPile().push(discardedCard);
	}

	private void endOfDeckReshuffle()
	{
		Card tempCard = pickupDiscard();
		getDeck().addCardsToDeck(getDiscardPile());
		getDiscardPile().clear();
		discard(tempCard);
		getDeck().shuffle();
	}


	private boolean isGameOver()
	{
		if(getScoreboard().getHighestScore() > MAXHIGHSCORE){
			return true;
		}
		return false;
	}
}
