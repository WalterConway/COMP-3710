package edu.auburn.eng.csse.comp3710.team05;

import java.util.ArrayList;

import edu.auburn.eng.csse.comp3710.team05.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PlayerAdapter extends BaseAdapter{
Context context;
Scoreboard sb;
int currentPlayer = -1;
ArrayList<Player> players;
	public PlayerAdapter(Context c, ArrayList<Player> playerList) {
		context = c;
		players = playerList;
		sb = Scoreboard.get(c.getApplicationContext());
	}
	
	public void setCurrentPlayerPosition(int position){
		currentPlayer = position;
	}
	
	public int getCurrentPlayerPosition(){
		return currentPlayer;
	}
	
	@Override
	public int getCount() {
		return players.size();
	}
	@Override
	public Player getItem(int arg0) {
		return players.get(arg0);
	}
	@Override
	public long getItemId(int position) {
		return players.get(position).hashCode();
	}
	@Override
	public View getView(int position, View convertView, ViewGroup viewgroup) {
		LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		if(convertView == null){
			convertView = (View)inflater.inflate(R.layout.player_row_item, viewgroup, false);
		}
		
		TextView playerNameTxtView = (TextView)convertView.findViewById(R.id.player_name_tv);
		TextView playerScoreTxtView = (TextView)convertView.findViewById(R.id.player_score_tv);
		LinearLayout playerLinearLayout = (LinearLayout)convertView.findViewById(R.id.playerll);
		playerNameTxtView.setText(players.get(position).getName());
		//playerScoreTxtView.setText(String.valueOf(players.get(position).getScore()));
		playerScoreTxtView.setText(String.valueOf(sb.getPlayerScore(players.get(position))));
		
		if(currentPlayer == position){
			playerLinearLayout.setBackgroundResource(R.drawable.playerbgselection);
		} else {
			playerLinearLayout.setBackgroundResource(R.drawable.playerbg);
		}
		
		return convertView;
	}

	

}
