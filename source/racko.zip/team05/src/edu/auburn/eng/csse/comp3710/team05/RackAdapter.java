package edu.auburn.eng.csse.comp3710.team05;

import edu.auburn.eng.csse.comp3710.team05.R;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class RackAdapter extends BaseAdapter{
Rack rack;
String[] arrayOfPoints;
Context context;
private int selectedPos = -1;
	public RackAdapter(Context c, Rack playerRack) {
		rack = playerRack;
		arrayOfPoints = c.getResources().getStringArray(R.array.point_of_slot);
		context = c;
		
	}

	@Override
	public int getCount() {
		return rack.getSize();
	}

	@Override
	public Card getItem(int arg0) {
		return rack.get(arg0);
	}

	public void setSelectedPosition(int position){
		selectedPos = position;
	}
	
	public int getSelectedPosition(){
		return selectedPos;
	}
	
	@Override
	public long getItemId(int position) {
		return rack.get(position).getFaceValue();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup viewGroup) {
		LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		if (convertView == null){
		convertView = inflater.inflate(R.layout.card_in_slot, viewGroup, false);
		} 
		TextView pointTextView = (TextView)convertView.findViewById(R.id.pointNumbertxtview);
		TextView cardNumberTextView = (TextView)convertView.findViewById(R.id.cardnum);
		LinearLayout cardSlotll = (LinearLayout)convertView.findViewById(R.id.cardslotll);
		int widthLL = cardSlotll.getMeasuredWidth();
		if(selectedPos == position){
			cardSlotll.setSelected(true);
		} else {
			cardSlotll.setSelected(false);
		}
		pointTextView.setText(arrayOfPoints[position]);
		cardNumberTextView.setText(String.valueOf(rack.get(position).getFaceValue()));
		int paddingSize = ((widthLL/60)*Integer.parseInt(cardNumberTextView.getText().toString()))-15;
		if(paddingSize < 0){
			paddingSize = 0;
		}
		cardNumberTextView.setPadding(paddingSize, 0, 0, 0);
		return convertView;
		
		
		
		
	}
	

}
