/** Automatically generated file. DO NOT MODIFY */
package edu.auburn.eng.csse.comp3710.team05;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}